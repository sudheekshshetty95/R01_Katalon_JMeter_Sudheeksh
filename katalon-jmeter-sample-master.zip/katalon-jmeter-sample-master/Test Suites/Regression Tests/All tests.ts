<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>All tests</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>c104d40b-6f5c-473e-b3c7-e680da52f0b3</testSuiteGuid>
   <testCaseLink>
      <guid>57c8d977-a551-47a5-979b-a740258feb38</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Simple examples/api-2-issue/Get issue/Get an issue by Key - 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c0619e7a-51e1-42f0-bb57-7ebd3909d465</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Simple examples/api-2-issue/Get issue/Get an issue by Key - 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fa1b8ae2-49eb-4211-8e23-ee25683d9ac8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Simple examples/api-2-issue/Edit issue/Edit an existing issue by Key</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>77c32f0e-0533-4f3f-b740-f7b03c27eb91</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Simple examples/api-2-issue/Create issue/Create a new issue</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3a23df0a-d51d-4d6e-b84f-b498e56af613</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Simple examples/api-2-search/Search issues/Search issues by jql</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fa6fdba4-5728-4e5b-8d12-3e0f10b4c267</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Simple examples/api-2-issue-comment/Add comment/Add a new comment into an existing issue</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f7a23161-ce2c-4229-a064-07216a7784bc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Advance examples/api-2-issue/Get issue/Get an issue by Key</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ab2f77a6-fb2d-4f66-8c9f-89ff288ca60f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Advance examples/api-2-issue/Edit issue/Edit an existing issue by Key</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f3e46912-df5d-4ef4-b890-3c7d5a9c79f4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Advance examples/api-2-issue/Create issue/Create a new issue</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d3f1367b-1f60-4c8d-b3c6-3d310be4e2c0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Advance examples/api-2-search/Search issues/Search issues by jql</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>83b29d11-de98-45ca-87c4-8520fa0ac66b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Advance examples/api-2-issue-comment/Add comment/Add a new comment into an existing issue</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4b92f7ff-980b-4baf-a9d5-a4a7a6e64f08</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Tips and Tricks/Parameterize/Parameterize request body</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>491dd05f-bad2-4b3c-a9de-2a3d9563ba8d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Tips and Tricks/Parameterize/Parameterize authentication</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1a5fb98a-cd4c-4e74-b99d-7f57652ef778</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Tips and Tricks/Parameterize/Parameterize request query</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a8ff8d69-e6ad-4a62-8a02-b1f99e707f93</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Tips and Tricks/Parameterize/Parameterize request path</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0e8dcc0d-43ec-492f-a4d3-9350a95594f1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Tips and Tricks/RequestObject/Get Request information</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>66aec38c-0813-4136-8a81-dcb8311590bc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Tips and Tricks/ResponseObject/Get Response information</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>98cc8467-ac2b-4564-896e-e3ac61ecbce3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Tips and Tricks/Verification/Verify simple json response using built-in keywords</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8af3b579-d824-4154-8043-26f1788e3b81</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Tips and Tricks/Authentication/Basic Authentication</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
