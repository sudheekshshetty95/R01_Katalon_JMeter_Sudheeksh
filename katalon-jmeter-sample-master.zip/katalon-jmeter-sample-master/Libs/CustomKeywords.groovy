
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */


def static "com.katalon.jmeter.JMeterKeyword.runJMeter"() {
    (new com.katalon.jmeter.JMeterKeyword()).runJMeter()
}
